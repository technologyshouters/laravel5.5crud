<!-- index.blade.php -->


<?php $__env->startSection('content'); ?>

  <div class="container">
  <a href="<?php echo e(action('CRUDController@create')); ?>" class="btn btn-warning">Create new item</a>
    <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Post Content</th>
        <th>Post Author</th>
        <th colspan="2">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $cruds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($post['id']); ?></td>
        <td><?php echo e($post['title']); ?></td>
        <td><?php echo e($post['post']); ?></td>
        <td><?php echo e($post['author']); ?></td>
        <td><a href="<?php echo e(action('CRUDController@edit', $post['id'])); ?>" class="btn btn-warning">Edit</a></td>
        <td>
          <form action="<?php echo e(action('CRUDController@destroy', $post['id'])); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <input name="_method" type="hidden" value="DELETE">
            <button class="btn btn-danger" type="submit">Delete</button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>